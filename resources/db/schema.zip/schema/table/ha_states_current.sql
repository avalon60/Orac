-- __author__: clive bostock
-- __date__: 2025-12-28
-- __description__: generated/synchronised by Cline; one object per file

create table orac.ha_states_current (
  entity_id           varchar2(255 char) not null,
  state               varchar2(255 char),
  attributes          clob,
  last_changed        timestamp with time zone,
  last_updated        timestamp with time zone,
  last_reported       timestamp with time zone,
  context_id          varchar2(64 char),
  context_parent_id   varchar2(64 char),
  context_user_id     varchar2(64 char),
  row_version         number not null,
  created_on          timestamp with time zone not null,
  updated_on          timestamp with time zone not null
);
