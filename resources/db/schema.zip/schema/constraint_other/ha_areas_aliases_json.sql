-- __author__: clive bostock
-- __date__: 2025-12-28
-- __description__: generated/synchronised by Cline; one object per file

alter table orac.ha_areas
  add constraint ha_areas_aliases_json
  check (aliases is json);
