"""Minimal package marker for bundled plugin manifest discovery."""
# Author: Clive Bostock
# Date: 2026-06-23
# Description: Keeps the portable PAT bundle focused on manifest discovery imports.
